﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace GuestApi.Models
{
    public class HotelBookingDbFinalContext : DbContext
    {
        public DbSet<Guest> Guests { get; set; }

        public HotelBookingDbFinalContext(DbContextOptions<HotelBookingDbFinalContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Guest>().ToTable("Guest");
        }
    }
}
