﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace GuestApi.Models
{
    public class Guest
    {
        [Key]
        public int Guest_Id { get; set; }
        public int Booking_Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int Phone_num { get; set; }


    }
}
