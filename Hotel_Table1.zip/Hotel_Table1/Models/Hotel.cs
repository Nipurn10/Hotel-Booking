﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Threading.Tasks;
using System.Linq;

namespace Hotel_Table1.Models
{
    public class Hotel
    {
        [Key]
        public int Hotel_Id { get;  set; }
        public string Hotel_name { get; set; }
        public string Location { get; set; }    
        public int Phone_num { get; set; }
        public int Rating { get; set; }
    }
}
