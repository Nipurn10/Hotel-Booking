﻿using Microsoft.EntityFrameworkCore;


namespace Hotel_Table1.Models
{
    public class HotelBookingDbFinalContext : DbContext
    {
        public DbSet<Hotel> Hotels { get; set; }

        public HotelBookingDbFinalContext(DbContextOptions<HotelBookingDbFinalContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            modelBuilder.Entity<Hotel>().ToTable("Hotel");
        }
    }
}
