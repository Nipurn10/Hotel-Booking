﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace BookingApi.Models
{
    public class HotelBookingDbFinalContext : DbContext
    {
        public DbSet<Booking> Bookings { get; set;}

        public HotelBookingDbFinalContext(DbContextOptions<HotelBookingDbFinalContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Booking>().ToTable("Booking");
        }
    }
}
