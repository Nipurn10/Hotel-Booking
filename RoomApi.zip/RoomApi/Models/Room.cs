﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RoomApi.Models
{
    public class Room
    {
        [Key]
        public int Room_num { get; set; }
        public int Hotel_Id { get; set; }
        public string Room_type { get; set; }
        public string Room_view { get; set; }
        public int Price { get; set; }
        public int Occupancy { get; set; }

    }
}
