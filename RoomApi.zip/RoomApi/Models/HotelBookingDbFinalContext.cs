﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace RoomApi.Models
{
    public class HotelBookingDbFinalContext : DbContext
    {
        public DbSet<Room> Rooms { get; set; }

        public HotelBookingDbFinalContext(DbContextOptions<HotelBookingDbFinalContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Room>().ToTable("Room");
        }
    }
}
